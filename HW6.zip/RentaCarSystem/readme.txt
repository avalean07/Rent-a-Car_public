In this readme.txt, the TA grading the assignment can find all the necessary information.
We created a folder called HW5 where the TA can find everything that is needed in order to grade the assignment. It includes all the script,forms,feedback folders organised for each entity and relationship.

Team comment 2: We managed to get the website running, but when we tried to make the server run locally, it cannot work. We couldn't manage
to get it running on MariaDB either, but I guess the TAs grading this will take care of it to test it themselves. The problem we have is
that we cannot submit and see the feedback, besides that, everything works accordingly.

The repo root directory in which the website URL can be found is:
/home/vgheorghe/Rent-a-Car_public/HW_5/RentaCarSystem
Kind Regards,
Rent-a-Car Team